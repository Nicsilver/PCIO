package dk.nicsilver.pcio.action.mouse.model;

import dk.nicsilver.pcio.action.ActionSender;

public class MouseActionHandler implements IMouseActionHandler
{
    private ActionSender actionSender;
    private float lastXLeft, lastYLeft, lastYRight, travelYRight;
    private boolean leftDown, rightDown = false;
    private boolean isMoveThresholdLeft, isMoveThresholdRight = false;
    private boolean isDragging, isLeftClickAboutToHappen, isDoubleTap = false;
    private long currentTimeMillisSnapshot = 0;
    
    public MouseActionHandler()
    {
        this.actionSender = ActionSender.getInstance();
    }
    
    @Override
    public void onDownLeft(float x, float y)
    {
        if (isLeftClickAboutToHappen)
        {
            isDoubleTap = true;
            new Thread(() -> //Start thread after a double tap. Then wait to see which action should be taken.
            {
                try
                {
                    Thread.sleep(150);
                    if (!isDragging)
                    {
                        if (leftDown)
                        {
                            actionSender.sendAction(MouseLibrary.onDrag());
                            this.isDragging = true;
                        } else
                        {
                            actionSender.sendAction(MouseLibrary.onLeftClick());
                        }
                    }
                    isDoubleTap = false;
                    isLeftClickAboutToHappen = false;
                } catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }).start();
        }
        currentTimeMillisSnapshot = System.currentTimeMillis(); //This is used to determine if we have double taps
        
        leftDown = true;
        isMoveThresholdLeft = false;
        lastXLeft = x;
        lastYLeft = y;
    }
    
    @Override
    public void onUpLeft(float x, float y)
    {
        if (isDragging)
        {
            this.actionSender.sendAction(MouseLibrary.onUpLeft());
            this.isDragging = false;
        } else if (isTimeElapsedLessThan(250) && !rightDown)
        {
            new Thread(() ->
            {
                isLeftClickAboutToHappen = true;
                try
                {
                    Thread.sleep(100);
                    if (!isDoubleTap && !isMoveThresholdLeft && !isDragging)
                    {
                        actionSender.sendAction(MouseLibrary.onLeftClick());
                    }
                } catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                isLeftClickAboutToHappen = false;
            }).start();
        } else if (!isMoveThresholdRight && rightDown)
        {
            this.actionSender.sendAction(MouseLibrary.onRightClick());
        }
        leftDown = false;
        rightDown = false;
    }
    
    private boolean isTimeElapsedLessThan(long timeDifference)
    {
        return System.currentTimeMillis() - currentTimeMillisSnapshot < timeDifference;
    }
    
    @Override
    public void onDownRight(float x, float y)
    {
        rightDown = true;
        isMoveThresholdRight = false;
        lastYRight = y;
        travelYRight = 0;
    }
    
    @Override
    public void onMoveLeft(float x, float y)
    {
        float xDifferenceFromLast = calculateMoveDifference(x, lastXLeft);
        float yDifferenceFromLast = calculateMoveDifference(y, lastYLeft);
        
        if (!rightDown && isMoveThresholdLeft
                && (isMoveThresholdMet(xDifferenceFromLast, 1)
                || isMoveThresholdMet(yDifferenceFromLast, 1)))
        {
            actionSender.sendAction(MouseLibrary.onMove(xDifferenceFromLast, yDifferenceFromLast));
        } else if (isMoveThresholdMet(xDifferenceFromLast, 1)
                || isMoveThresholdMet(yDifferenceFromLast, 1))
        {
            isMoveThresholdLeft = true; // This is to filter out the first movement, it can sometimes be jerky if this is not done.
            if (isDoubleTap)
            {
                this.isDragging = true;
                this.isDoubleTap = false;
                actionSender.sendAction(MouseLibrary.onDrag());
            }
        }
        lastXLeft = x;
        lastYLeft = y;
    }
    
    private float calculateMoveDifference(float currentValue, float lastValue)
    {
        return currentValue - lastValue;
    }
    
    /**
     * Return true if value is more than threshold, either negative or positive.
     * @param value to test
     * @param threshHold to test on
     * @return true if larger than, threshold false if not
     */
    private boolean isMoveThresholdMet(float value, float threshHold)
    {
        return value > threshHold || value < -threshHold;
    }
    
    @Override
    public void onMoveRight(float y)
    {
        if (leftDown && rightDown)
        {
            float sendY = calculateMoveDifference(y, lastYRight);
            travelYRight += sendY;
            lastYRight = y;
            
            if (isMoveThresholdMet(travelYRight, 10))
            {
                actionSender.sendAction(MouseLibrary.onScroll(sendY / 2));
                travelYRight = 0;
                isMoveThresholdRight = true;
            }
        }
    }
}
