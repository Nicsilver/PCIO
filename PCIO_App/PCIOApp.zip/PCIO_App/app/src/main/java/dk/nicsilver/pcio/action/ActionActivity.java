package dk.nicsilver.pcio.action;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.nicsilver.pcio.R;

import dk.nicsilver.pcio.select.SelectActivity;

public class ActionActivity extends AppCompatActivity implements ActionContract.view
{
    private ActionContract.presenter presenter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.action_activity);
        
        Intent intent = getIntent();
        String port = intent.getStringExtra(SelectActivity.PORT_MESSAGE);
        String ip = intent.getStringExtra(SelectActivity.IP_MESSAGE);
        
        presenter = new ActionPresenter(this, ip, port);
    }
    
    @Override
    public void onConnectionLost()
    {
    
    }
    
    @Override
    public void onConnectionRegained()
    {
    
    }
}